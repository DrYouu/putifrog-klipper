# Leapfrog-Creatr-HS-New-Firmware
Latest Marlin firmware for Leapfrog Creatr Hs based on Marlin 1.1.9
100% Compatible with the original mainboard

More functions will follow soon

Stock firmware also included just incase you need it
